"use strict";

var changelog_generated = {
    "20th Feb 2023": [{
        id: 1,
        description: "Test Loading screen", 
        author: "Sha4ow",
        added_at: "20th Feb 2023"
    }]
    
};
