-- 🌟 Loading Screen Configuration 🌟
fx_version 'bodacious' -- Bodacious version

-- 🎮 Supported Games 🎮
games { 'gta5', } -- Supported game(s): GTA 5

author 'Sha4ow#3246' -- Author information: Sha4ow#3246

-- 💬 Description 💬
description 'Simple FiveM loading screen' 

-- 🔢 Version 🔢
version '1.0' 

-- 🚀 Manual Shutdown 🚀
loadscreen_manual_shutdown "yes" -- Skip Bridge Animation 

-- 🗂️ File List 🗂️

server_script {
    
    'version_check.lua'
}

files {
    'assets/**/*.*', -- Asset files (including subdirectories)
    'data/changelog.js', -- Changelog data
    'index.html', -- HTML file
    'style.css', -- CSS file
    'script.js', -- JavaScript file
    'lib/vue.js', -- Vue.js library
    'lib/vue.min.js', -- Minified Vue.js library
    'lib/lodash.js', -- Lodash library
    'lib/moment.min.js', -- Minified Moment.js library
}

-- 📄 Loadscreen Configuration 📄
loadscreen 'index.html' -- Loading screen file: index.html
